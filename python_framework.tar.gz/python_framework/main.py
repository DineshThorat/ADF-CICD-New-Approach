from fastapi import FastAPI
from src.models import qaModel

app = FastAPI()


@app.get("/")
def read_root():
    return "Text to SQL Chatbot"


@app.post("/text2sql")
def qa(data: qaModel):
    return "Thanks for visiting. Development in progress...."
