# Use the Conversation API to send a text message to Amazon Titan Text.
import json
import boto3
import logging
import botocore
from botocore.exceptions import ClientError
from typing import List, Dict
from adapters.utils import measure_time
from adapters.exceptions.bedrock_exceptions import (
    BedrockInferenceError,
    BedrockConnectionError,
)

# Setup loggeing
logging.basicConfig(level=logging.INFO)
logging.basicConfig(
    filename="logs.log",
    format="{asctime} - {levelname} - {message}",
    style="{",
    datefmt="%Y-%m-%d %H:%M",
)
bedrock_logger = logging.getLogger(__name__)


class Bedrock:
    def __init__(self, region_name: str = "us-east-1"):
        try:
            bedrock_logger.info("[Bedrock] - Setting up client")
            # Create Bedrock Runtime client config
            self.client_config = botocore.config.Config(
                max_pool_connections=10, connect_timeout=60
            )
            # Create a Bedrock Runtime client in the AWS Region you want to use.
            self.client = boto3.client(
                "bedrock-runtime", region_name=region_name, config=self.client_config
            )
            assert 1 == 2
            bedrock_logger.info("[Bedrock] - Client created successfuly")
        except Exception as ex:
            bedrock_logger.error("[Bedrock] - Client Setup Failed", exc_info=True)
            raise BedrockConnectionError(f"Connection failed: {str(ex)}")

    @measure_time
    async def async_converse(
        self,
        transaction_id: str,
        model_id: str,
        messages: List[Dict],
        model_params: Dict[str, str],
    ):

        try:
            bedrock_logger.info(
                f"[Bedrock][async_converse][{transaction_id}] - Creating async Completion Call"
            )
            # Send the message to the model, using a basic inference configuration.
            response = self.client.converse(
                modelId=model_id,
                messages=messages,
                inferenceConfig=model_params,
            )
            bedrock_logger.info(
                f"[Bedrock][async_converse][{transaction_id}] - Creating async Completion Sucessfull"
            )
            return response
        except (ClientError, Exception) as ex:
            bedrock_logger.error(
                f"[Bedrock][async_converse][{transaction_id}] - async Completion Called Failed",
                exc_info=True,
            )
            raise BedrockInferenceError(f"Bedrock async converse failed : {str(ex)}")

    @measure_time
    def converse(
        self,
        transaction_id: str,
        model_id: str,
        messages: List[Dict],
        model_params: Dict[str, str],
    ):

        try:
            bedrock_logger.info(
                f"[Bedrock][converse][{transaction_id}] - Creating Completion Call"
            )
            # Send the message to the model, using a basic inference configuration.
            response = self.client.converse(
                modelId=model_id,
                messages=messages,
                inferenceConfig=model_params,
            )

            bedrock_logger.info(
                f"[Bedrock][converse][{transaction_id}] - Completion Sucessful"
            )
            return response
        except (ClientError, Exception) as ex:
            bedrock_logger.error(
                f"[Bedrock][converse][{transaction_id}] - Completion Call Failed",
                exc_info=True,
            )
            raise BedrockInferenceError(f"Bedrock converse failed : {str(ex)}")

    async def async_converse_stream(
        self,
        transaction_id: str,
        model_id: str,
        messages: List[Dict],
        model_params: Dict[str, str],
    ):
        try:
            bedrock_logger.info(
                f"[Bedrock][async_converse_stream][{transaction_id}] - Creating async Stream Completion Call"
            )
            # Send the message to the model, using a basic inference configuration.
            streaming_response = self.client.converse_stream(
                modelId=model_id,
                messages=messages,
                inferenceConfig=model_params,
            )
            bedrock_logger.info(
                f"[Bedrock][async_converse_stream][{transaction_id}] - async Stream Completion Sucessfull"
            )
            return streaming_response

        except (ClientError, Exception) as ex:
            bedrock_logger.error(
                f"[Bedrock][async_converse_stream][{transaction_id}] - async Stream Completion Call Failed",
                exc_info=True,
            )
            raise BedrockInferenceError(
                f"Bedrock async converse stream failed : {str(ex)}"
            )

    def converse_stream(
        self,
        transaction_id: str,
        model_id: str,
        messages: List[Dict],
        model_params: Dict[str, str],
    ):
        try:
            bedrock_logger.info(
                f"[Bedrock][converse_stream][{transaction_id}] - Creating Stream Completion Call"
            )
            # Send the message to the model, using a basic inference configuration.
            streaming_response = self.client.converse_stream(
                modelId=model_id,
                messages=messages,
                inferenceConfig=model_params,
            )
            bedrock_logger.info(
                f"[Bedrock][converse_stream][{transaction_id}] - Stream Completion Sucessfull"
            )
            return streaming_response

        except (ClientError, Exception) as ex:
            bedrock_logger.error(
                f"[Bedrock][converse_stream][{transaction_id}] - Stream Completion Call Failed",
                exc_info=True,
            )
            raise BedrockInferenceError(f"Bedrock converse stream failed : {str(ex)}")

    @measure_time
    async def async_embeddings(
        self,
        transaction_id: str,
        model_id: str,
        body: List[Dict],
    ):
        try:
            bedrock_logger.info(
                f"[Bedrock][async_embeddings][{transaction_id}] - Creating async Embedding call"
            )
            # Invoke the model with the request.
            response = self.client.invoke_model(modelId=model_id, body=json.dumps(body))
            bedrock_logger.info(
                f"[Bedrock][async_embeddings][{transaction_id}] - async Embedding call Sucessfull"
            )
            return response
        except (ClientError, Exception) as ex:
            bedrock_logger.error(
                f"[Bedrock][async_embeddings][{transaction_id}] - async Embedding call Failed",
                exc_info=True,
            )
            raise BedrockInferenceError(f"Bedrock async embedding failed : {str(ex)}")

    @measure_time
    def embeddings(
        self,
        transaction_id: str,
        model_id: str,
        body: List[Dict],
    ):
        try:
            bedrock_logger.info(
                f"[Bedrock][embeddings][{transaction_id}] - Creating Embedding call"
            )
            # Invoke the model with the request.
            response = self.client.invoke_model(modelId=model_id, body=json.dumps(body))
            bedrock_logger.info(
                f"[Bedrock][embeddings][{transaction_id}] - Embedding call Sucessfull"
            )
            return response
        except (ClientError, Exception) as ex:
            bedrock_logger.error(
                f"[Bedrock][embeddings][{transaction_id}] - Embedding call Failed",
                exc_info=True,
            )
            raise BedrockInferenceError(f"Bedrock embedding failed : {str(ex)}")


bedrock_client = Bedrock(region_name="us-east-1")
