# import botocore
# import logging
# import pymysql
# import sys
# import boto3
# import os


# # Setup loggeing
# logging.basicConfig(level=logging.DEBUG)
# logging.basicConfig(
#     filename="logs.log",
#     format="{asctime} - {levelname} - {message}",
#     style="{",
#     datefmt="%Y-%m-%d %H:%M",
# )
# aurora_logger = logging.getLogger("aurora")


# class Aurora:
#     def __init__(self, region_name: str = "us-east-1"):
#         self.endpoint = ""
#         self.port = ""
#         self.user = ""
#         self.dbname = ""
#         try:
#             aurora_logger.info("[Aurora] - Setting up client")
#             # Create Bedrock Runtime client config
#             self.client_config = botocore.config.Config(
#                 max_pool_connections=10, connect_timeout=60
#             )
#             # Create a Bedrock Runtime client in the AWS Region you want to use.
#             self.client = boto3.client(
#                 "rds", region_name=region_name, config=self.client_config
#             )
#             token = self.client.generate_db_auth_token(
#                 DBHostname=self.endpoint,
#                 Port=self.port,
#                 DBUsername=self.user,
#                 Region=region_name,
#             )
#             aurora_logger.info("[Aurora] - Client created successfuly")
#         except Exception as ex:
#             aurora_logger.error("[Aurora] - Client Setup Failed")
#             raise
