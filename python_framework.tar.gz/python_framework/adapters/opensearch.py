from opensearchpy import (
    OpenSearch,
    RequestsHttpConnection,
    AWSV4SignerAuth,
    Urllib3AWSV4SignerAuth,
    Urllib3HttpConnection,
)
import boto3
import botocore
import logging
from typing import Dict, List, Tuple, Any
from opensearchpy import helpers
from adapters.utils import measure_time
from adapters.exceptions.opensearch_exceptions import (
    OpenSearchConnectionError,
    OpenSearchQueryError,
    OpenSearchIndexError,
)

# Setup logging
logging.basicConfig(
    filename="logs.log",
    level=logging.INFO,
    format="{asctime} - {levelname} - {message}",
    style="{",
    datefmt="%Y-%m-%d %H:%M",
)
opensearch_logger = logging.getLogger("opensearch")


class Opensearch:
    def __init__(
        self,
        host: str,
        service: str = "aoss",
        region_name: str = "us-east-1",
        port: int = 443,
    ):
        try:
            opensearch_logger.info("[Opensearch] - Initializing OpenSearch client")

            credentials = boto3.Session().get_credentials()
            auth = Urllib3AWSV4SignerAuth(credentials, region_name, service)

            # Create opensearch serviceless client
            self.client = OpenSearch(
                hosts=[{"host": host, "port": port}],
                http_auth=auth,
                use_ssl=True,
                verify_certs=True,
                connection_class=Urllib3HttpConnection,
                pool_maxsize=20,
            )
            opensearch_logger.info(
                "[Opensearch] - OpenSearch client initialized successfully"
            )
        except Exception as ex:
            opensearch_logger.error("[Opensearch] - Client Setup Failed")
            raise OpenSearchConnectionError(f"Connection failed : {str(ex)}")

    @measure_time
    def create_index(
        self, transaction_id: str, index_name: str, index_body: str = None
    ):

        if not index_body:
            opensearch_logger.warning(
                f"[Opensearch][create_index][{transaction_id}] - Using default index configuration"
            )
            index_body = {
                "settings": {"index": {"knn": True, "knn.algo_param.ef_search": 100}},
                "mappings": {  # how do we store,
                    "properties": {
                        "embedding": {
                            "type": "knn_vector",  # we are going to put
                            "dimension": 1560,
                            "method": {
                                "name": "hnsw",
                                "space_type": "l2",
                                "engine": "nmslib",
                                "parameters": {"ef_construction": 128, "m": 24},
                            },
                        }
                    }
                },
            }
        try:
            opensearch_logger.info(
                f"[Opensearch][create_index][{transaction_id}] - Creating index: {index_name}"
            )
            response = self.client.indices.create(index=index_name, body=index_body)
            opensearch_logger.info(
                f"[Opensearch][create_index][{transaction_id}] - Index created successfully"
            )
            return response
        except Exception as ex:
            opensearch_logger.error(
                f"[Opensearch][create_index][{transaction_id}] - Index creation Failed"
            )
            raise OpenSearchIndexError(f"Index creation failed : {str(ex)}")

    @measure_time
    def delete_index(self, transaction_id: str, index_name: str, id: Any):
        try:
            opensearch_logger.info(
                f"[Opensearch][delete_index][{transaction_id}] - Deleting {index_name} index"
            )
            response = self.client.indices.delete(index=index_name)
            opensearch_logger.info(
                f"[Opensearch][delete_index][{transaction_id}] - Index Deleted sucessful"
            )
            return response
        except Exception as ex:
            opensearch_logger.info(
                f"[Opensearch][delete_index][{transaction_id}] - Index Deletion Failed"
            )
            raise OpenSearchIndexError(f"Index deletion failed : {str(ex)}")

    @measure_time
    def insert_document(
        self, transaction_id: str, index_name: str, doc: Dict[str, str]
    ):
        try:
            opensearch_logger.info(
                f"[Opensearch][insert_document][{transaction_id}] - Adding doc in {index_name} index"
            )
            response = self.client.index(index=index_name, body=doc)
            opensearch_logger.info(
                f"[Opensearch][insert_document][{transaction_id}] - Doc addition sucessful"
            )
            return response
        except Exception as ex:
            opensearch_logger.error(
                f"[Opensearch][insert_document][{transaction_id}] - Doc addition failed"
            )
            raise OpenSearchIndexError(f"Index insertion failed : {str(ex)}")

    @measure_time
    def bulk_insert_document(
        self, transaction_id: str, index_name: str, docs: List[Dict[str, str]]
    ):

        try:
            opensearch_logger.info(
                f"[Opensearch][bulk_insert_document][{transaction_id}] - Adding docs in {index_name} index"
            )
            response = helpers.bulk(self.client, docs, index_name)
            opensearch_logger.info(
                f"[Opensearch][bulk_insert_document][{transaction_id}] - Docs addition sucessful"
            )
            return response
        except Exception as ex:
            opensearch_logger.error(
                f"[Opensearch][bulk_insert_document][{transaction_id}] - Docs addition failed"
            )
            raise OpenSearchIndexError(f"Index bulk insertion failed : {str(ex)}")

    @measure_time
    def delete_document(self, transaction_id: str, index_name: str, id: Any):
        try:
            opensearch_logger.info(
                f"[Opensearch][delete_document][{transaction_id}] - Deleting doc in {index_name} index"
            )
            response = self.client.delete(index=index_name, id=id)
            opensearch_logger.info(
                f"[Opensearch][delete_document][{transaction_id}] - Doc Deletion sucessful"
            )
            return response
        except Exception as ex:
            opensearch_logger.info(
                f"[Opensearch][delete_document][{transaction_id}] - Doc Deletion Failed"
            )
            raise OpenSearchIndexError(f"Document deletion failed : {str(ex)}")

    @measure_time
    def search_document(
        self, transaction_id: str, index_name: str, query_body: Dict[str, Any]
    ):
        try:
            opensearch_logger.info(
                f"[Opensearch][search_document][{transaction_id}] - Searching docs in {index_name} index"
            )
            result = self.client.search(body=query_body, index=index_name)
            opensearch_logger.info(
                f"[Opensearch][search_document][{transaction_id}] - Doc searching sucessful"
            )
            return result
        except Exception as ex:
            opensearch_logger.info(
                f"[Opensearch][search_document][{transaction_id}] - Doc searching Failed"
            )
            raise OpenSearchQueryError(f"Search query failed : {str(ex)}")


opensearch_host = "<host url for opensearch>"
opensearch_servie = "<opensearch service type>"
opensearch_region = "<opensearch region name>"

opensearch_client = Opensearch(
    host=opensearch_host,
    service=opensearch_servie,
    region_name=opensearch_region,
)
