from .base_exception import AdapterException

class BedrockException(AdapterException):
    """Exception class for Bedrock adapter errors."""
    pass

class BedrockConnectionError(BedrockException):
    """Raised when there is a connection issue with OpenSearch."""
    pass

class BedrockInferenceError(BedrockException):
    """Raised when there is an issue with inference on Bedrock."""
    pass
