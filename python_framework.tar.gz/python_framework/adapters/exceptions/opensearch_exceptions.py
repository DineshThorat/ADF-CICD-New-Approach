from .base_exception import AdapterException

class OpenSearchException(AdapterException):
    """Exception class for OpenSearch adapter errors."""
    pass

class OpenSearchConnectionError(OpenSearchException):
    """Raised when there is a connection issue with OpenSearch."""
    pass

class OpenSearchQueryError(OpenSearchException):
    """Raised for query-related issues in OpenSearch."""
    pass

class OpenSearchIndexError(OpenSearchException):
    """Raised for index-related issues in OpenSearch."""
    pass
