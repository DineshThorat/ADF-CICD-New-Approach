import time
import asyncio
import functools


def measure_time(func):
    """Decorator to measure execution time for both sync and async functions."""

    if asyncio.iscoroutinefunction(func):

        @functools.wraps(func)
        async def async_wrapper(self, *args, exc_time=False, **kwargs):
            start_time = time.time()
            result = await func(self, *args, **kwargs)
            exec_time = time.time() - start_time
            return (result, exec_time) if exc_time else result

        return async_wrapper

    @functools.wraps(func)
    def sync_wrapper(self, *args, exc_time=False, **kwargs):
        start_time = time.time()
        result = func(self, *args, **kwargs)
        exec_time = time.time() - start_time
        return (result, exec_time) if exc_time else result

    return sync_wrapper
