from pydantic import BaseModel

"""
TODO: Implement any of the data model for the adapters
"""