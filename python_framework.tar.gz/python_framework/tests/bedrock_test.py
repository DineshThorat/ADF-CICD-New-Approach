import unittest
from unittest.mock import patch, MagicMock
from adapters.bedrock import Bedrock
import asyncio

class TestBedrock(unittest.TestCase):

    @patch("boto3.client")
    def test_init(self, mock_boto_client):
        """Test Bedrock class initialization."""
        # Mock client creation
        mock_client_instance = MagicMock()
        mock_boto_client.return_value = mock_client_instance

        # Instantiate Bedrock
        bedrock_client = Bedrock(region_name="us-west-2")

        # Assert client was created with correct parameters
        mock_boto_client.assert_called_with(
            "bedrock-runtime",
            region_name="us-west-2",
            config=bedrock_client.client_config
        )
        self.assertEqual(bedrock_client.client, mock_client_instance)

    @patch("boto3.client")
    def test_converse(self, mock_boto_client):
        """Test the synchronous converse method."""
        mock_client_instance = MagicMock()
        mock_client_instance.converse.return_value = {"response": "test_converse"}
        mock_boto_client.return_value = mock_client_instance

        bedrock_client = Bedrock()

        response = bedrock_client.converse(
            transaction_id="123",
            model_id="test-model",
            messages=[{"message": "Hello Titan"}],
            model_params={"temperature": 0.5}
        )

        self.assertEqual(response, {"response": "test_converse"})
        mock_client_instance.converse.assert_called_once_with(
            modelId="test-model",
            messages=[{"message": "Hello Titan"}],
            inferenceConfig={"temperature": 0.5}
        )

    @patch("boto3.client")
    def test_converse_stream(self, mock_boto_client):
        """Test the synchronous converse_stream method."""
        mock_client_instance = MagicMock()
        mock_client_instance.converse_stream.return_value = {"stream_response": True}
        mock_boto_client.return_value = mock_client_instance

        bedrock_client = Bedrock()

        response = bedrock_client.converse_stream(
            transaction_id="123",
            model_id="test-model",
            messages=[{"message": "Stream Message"}],
            model_params={"temperature": 0.5}
        )

        self.assertEqual(response, {"stream_response": True})
        mock_client_instance.converse_stream.assert_called_once_with(
            modelId="test-model",
            messages=[{"message": "Stream Message"}],
            inferenceConfig={"temperature": 0.5}
        )

    @patch("boto3.client")
    def test_embeddings(self, mock_boto_client):
        """Test the synchronous embeddings method."""
        mock_client_instance = MagicMock()
        mock_client_instance.invoke_model.return_value = {"embedding_vector": [0.1, 0.2]}
        mock_boto_client.return_value = mock_client_instance

        bedrock_client = Bedrock()

        response = bedrock_client.embeddings(
            transaction_id="123",
            model_id="embedding-model",
            body=[{"text": "hello world"}]
        )

        self.assertEqual(response, {"embedding_vector": [0.1, 0.2]})
        mock_client_instance.invoke_model.assert_called_once_with(
            modelId="embedding-model",
            body=[{"text": "hello world"}]
        )

    @patch("boto3.client")
    def test_async_converse(self, mock_boto_client):
        """Test the async converse method using asyncio.run."""
        mock_client_instance = MagicMock()
        mock_client_instance.converse.return_value = {"response": "async_converse"}
        mock_boto_client.return_value = mock_client_instance

        bedrock_client = Bedrock()

        async def run_test():
            response = await bedrock_client.async_converse(
                transaction_id="async123",
                model_id="async-model",
                messages=[{"message": "Hello Titan async"}],
                model_params={"temperature": 0.7}
            )
            return response

        response = asyncio.run(run_test())
        self.assertEqual(response, {"response": "async_converse"})
        mock_client_instance.converse.assert_called_once_with(
            modelId="async-model",
            messages=[{"message": "Hello Titan async"}],
            inferenceConfig={"temperature": 0.7}
        )

    @patch("boto3.client")
    def test_async_converse_stream(self, mock_boto_client):
        """Test the async converse_stream method."""
        mock_client_instance = MagicMock()
        mock_client_instance.converse_stream.return_value = {
            "stream_response": "async_stream"
        }
        mock_boto_client.return_value = mock_client_instance

        bedrock_client = Bedrock()

        async def run_test():
            response = await bedrock_client.async_converse_stream(
                transaction_id="stream123",
                model_id="stream-model",
                messages=[{"message": "Stream me"}],
                model_params={"temperature": 0.9}
            )
            return response

        response = asyncio.run(run_test())
        self.assertEqual(response, {"stream_response": "async_stream"})
        mock_client_instance.converse_stream.assert_called_once_with(
            modelId="stream-model",
            messages=[{"message": "Stream me"}],
            inferenceConfig={"temperature": 0.9}
        )

    @patch("boto3.client")
    def test_async_embeddings(self, mock_boto_client):
        """Test the async embeddings method."""
        mock_client_instance = MagicMock()
        mock_client_instance.invoke_model.return_value = {
            "embedding_vector": [0.9, 0.8, 0.7]
        }
        mock_boto_client.return_value = mock_client_instance

        bedrock_client = Bedrock()

        async def run_test():
            response = await bedrock_client.async_embeddings(
                transaction_id="embed123",
                model_id="embed-model",
                body=[{"text": "async embedding"}]
            )
            return response

        response = asyncio.run(run_test())
        self.assertEqual(response, {"embedding_vector": [0.9, 0.8, 0.7]})
        mock_client_instance.invoke_model.assert_called_once_with(
            modelId="embed-model",
            body=[{"text": "async embedding"}]
        )


if __name__ == "__main__":
    unittest.main()