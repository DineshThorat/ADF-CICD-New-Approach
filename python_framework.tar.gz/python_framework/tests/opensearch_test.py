import unittest
from unittest.mock import patch, MagicMock
from opensearchpy import OpenSearch
from adapters.opensearch import Opensearch  # Replace 'your_module' with the actual module name

class TestOpensearch(unittest.TestCase):
    @patch("adapters.opensearch.OpenSearch")
    @patch("adapters.opensearch.boto3.Session")
    def setUp(self, mock_boto_session, mock_opensearch):
        self.mock_client = MagicMock()
        mock_opensearch.return_value = self.mock_client
        mock_boto_session.return_value.get_credentials.return_value = MagicMock()
        
        self.opensearch = Opensearch(host="test-host")

    def test_create_index(self):
        self.mock_client.indices.create.return_value = {"acknowledged": True}
        response = self.opensearch.create_index("tx123", "test-index")
        self.assertEqual(response["acknowledged"], True)
        self.mock_client.indices.create.assert_called_once()

    def test_insert_document(self):
        self.mock_client.index.return_value = {"_id": "1", "result": "created"}
        response = self.opensearch.insert_document("tx123", "test-index", {"name": "test"})
        self.assertEqual(response["result"], "created")
        self.mock_client.index.assert_called_once()

    def test_bulk_insert_document(self):
        with patch("your_module.helpers.bulk") as mock_bulk:
            mock_bulk.return_value = (1, [])
            response = self.opensearch.bulk_insert_document("tx123", "test-index", [{"name": "test"}])
            self.assertEqual(response, (1, []))
            mock_bulk.assert_called_once()

    def test_delete_document(self):
        self.mock_client.delete.return_value = {"result": "deleted"}
        response = self.opensearch.delete_document("tx123", "test-index", "1")
        self.assertEqual(response["result"], "deleted")
        self.mock_client.delete.assert_called_once()

    def test_search_document(self):
        self.mock_client.search.return_value = {"hits": {"hits": [{"_id": "1", "_source": {"name": "test"}}]}}
        response = self.opensearch.search_document("tx123", "test-index", {"query": {"match_all": {}}})
        self.assertEqual(len(response["hits"]["hits"]), 1)
        self.mock_client.search.assert_called_once()

if __name__ == "__main__":
    unittest.main()
