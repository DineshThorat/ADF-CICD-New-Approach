import json
from pydantic import BaseModel
from uuid import uuid4
from typing import List, Dict, Tuple
from datetime import datetime


class qaModel(BaseModel):
    id: str
    query: str
    timestamp: str


class ConversationModel(qaModel):
    sqlResponse: str
    textResponse: str
    graphResponse: str
    tableResponse: str

    def to_dict(self):
        """
        Convert the model to a dictionary, encoding any list or dictionary values as JSON strings.
        """
        model_dict = self.model_dump()
        for key, value in model_dict.items():
            if isinstance(value, list) or isinstance(value, dict):
                model_dict[key] = json.dumps(value)
        return model_dict


class OpenSearchModel(BaseModel):
    # id: str = None ToDo an auto increament over database
    conversationID: str = None
    searchIndex: List[str] = []
    searchQuery: List[str] = []
    searchResult: List[str] = []
    executionTime: List[float] = []

    def to_dict(self):
        """
        Convert the model to a dictionary, encoding any list or dictionary values as JSON strings.
        """
        model_dict = self.model_dump()
        for key, value in model_dict.items():
            if isinstance(value, list):
                updated_value = []
                for sub_value in value:
                    if isinstance(sub_value, list) or isinstance(sub_value, dict):
                        updated_value.append(json.dumps(sub_value))
                    else:
                        updated_value.append(sub_value)
                model_dict[key] = updated_value
        return model_dict


class BedrockModel(BaseModel):
    # id: str = None ToDo an auto increament over database
    conversationID: str = None
    callType: List[str] = []
    inputToken: List[int] = []
    outputToken: List[int] = []
    totalToken: List[int] = []
    response: List[int] = []
    executionTime: List[float] = []

    def to_dict(self):
        """
        Convert the model to a dictionary, encoding any list or dictionary values as JSON strings.
        """
        model_dict = self.model_dump()
        for key, value in model_dict.items():
            if isinstance(value, list):
                updated_value = []
                for sub_value in value:
                    if isinstance(sub_value, list) or isinstance(sub_value, dict):
                        updated_value.append(json.dumps(sub_value))
                    else:
                        updated_value.append(sub_value)
                model_dict[key] = updated_value
        return model_dict


class APILogs(BaseModel):
    id: str
    conversationID: str
    route: str
    inputParams: str
    outputParams: str
    error: str
    inTime: datetime
    outTime: datetime
