import json
from src.logger import logger
from src.exception import PromptBuilderException


def text2sql_prompt_builder(transaction_id: str, query: str, schema: str):
    """
    Method to create prompt structure for text to sql conversion
    TODO: include fetch_prompt to retrive the prompt from database
    """
    base_prompt = """Based on the below schema provide me the a sql query
schema: {}

query : {}"""

    try:
        logger.info(
            f"[prompts][text2sql_prompt_builder][{transaction_id}] - creation prompt"
        )
        messages = [
            {"role": "user", "content": [{"text": base_prompt.format(schema, query)}]}
        ]
        logger.info(
            f"[prompts][text2sql_prompt_builder][{transaction_id}] - prompt created"
        )
    except (KeyError, ValueError, IndexError, AttributeError, TypeError) as ex:
        logger.error(
            f"[prompts][text2sql_prompt_builder][{transaction_id}] - Error {ex}"
        )
        raise PromptBuilderException(f"Prompt builder failed : {ex}")
    except Exception as ex:
        logger.error(
            f"[prompts][text2sql_prompt_builder][{transaction_id}] - Error {ex}"
        )
        raise PromptBuilderException(f"Prompt builder failed : {ex}")
    return messages


def graph_prompt_builder(transaction_id: str, data: str, query: str):
    """
    Method to create prompt structure for graph generation using bedrock
    TODO: include fetch_prompt to retrive the prompt from database
    """
    base_prompt = """Based on the below data provide me the a graph query
data: {}

query : {}"""

    try:
        logger.info(
            f"[prompts][graph_prompt_builder][{transaction_id}] - creation prompt"
        )
        messages = [
            {"role": "user", "content": [{"text": base_prompt.format(data, query)}]}
        ]
        logger.info(
            f"[prompts][graph_prompt_builder][{transaction_id}] - prompt created"
        )
    except (KeyError, ValueError, IndexError, AttributeError, TypeError) as ex:
        logger.error(f"[prompts][graph_prompt_builder][{transaction_id}] - Error {ex}")
        raise PromptBuilderException(f"Prompt builder failed : {ex}")
    except Exception as ex:
        logger.error(f"[prompts][graph_prompt_builder][{transaction_id}] - Error {ex}")
        raise PromptBuilderException(f"Prompt builder failed : {ex}")
    return messages


def sum_prompt_builder(transaction_id: str, data: str, query: str):
    """
    Method to create prompt structure for text generation from the text query, sql  query and databricks output
    TODO: include fetch_prompt to retrive the prompt from database
    """
    base_prompt = """Based on the below data provide me the a intro text
data: {}

query : {}"""

    try:
        logger.info(
            f"[prompts][sum_prompt_builder][{transaction_id}] - creation prompt"
        )
        messages = [
            {"role": "user", "content": [{"text": base_prompt.format(data, query)}]}
        ]
        logger.info(f"[prompts][sum_prompt_builder][{transaction_id}] - prompt created")
    except (KeyError, ValueError, IndexError, AttributeError, TypeError) as ex:
        logger.error(f"[prompts][sum_prompt_builder][{transaction_id}] - Error {ex}")
        raise PromptBuilderException(f"Prompt builder failed : {ex}")
    except Exception as ex:
        logger.error(f"[prompts][sum_prompt_builder][{transaction_id}] - Error {ex}")
        raise PromptBuilderException(f"Prompt builder failed : {ex}")
    return messages
