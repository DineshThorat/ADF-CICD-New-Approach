class BaseException(Exception):
    """Base class for all src-related exceptions."""

    def __init__(self, message: str):
        super().__init__(message)
        self.message = message


class PromptBuilderException(BaseException):
    """Exception class for Bedrock adapter errors."""

    pass


class PromptBuilderException(BaseException):
    """Exception class for Bedrock adapter errors."""

    pass