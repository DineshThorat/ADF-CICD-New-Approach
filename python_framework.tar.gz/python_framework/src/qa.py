from adapters.opensearch import opensearch_client
from adapters.bedrock import bedrock_client
from src.models import qaModel, ConversationModel, BedrockModel, OpenSearchModel
from src.utils import text2sql_response_parser
from src.prompts import (
    text2sql_prompt_builder,
    graph_prompt_builder,
    sum_prompt_builder,
)


class qa:
    def __init__(self, qaModel):

        self.conversation = ConversationModel(**qaModel)
        self.bedrock = BedrockModel()
        self.bedrock.conversationID = self.conversation.id
        self.opensearch = OpenSearchModel()
        self.opensearch.conversationID = self.conversation.id

    async def text2sql(self):

        # generate the embedding of the query
        body = {"inputText": self.conversation.query}
        query_embedding_response, exc_time = await bedrock_client.async_embeddings(
            transaction_id=self.conversation.id, model_id="", body=body, exc_time=True
        )
        self.bedrock.callType.append("embedding")
        self.bedrock.inputToken.append("to be checked")
        self.bedrock.outputToken.append("to be checked")
        self.bedrock.totalToken.append("to be calculated")
        self.bedrock.response.append(query_embedding_response)
        self.bedrock.executionTime.append(exc_time)

        # perform vector search for the few shots
        # To be figured out
        # perform vector search for the relevent table
        table_result, exc_time = opensearch_client.search_document(
            transaction_id=self.conversation.id, index_name="table index", query_body={}
        )
        self.opensearch.searchIndex.append("table index")
        self.opensearch.searchQuery.append({})
        self.opensearch.searchResult.append(table_result)
        self.opensearch.executionTime.append(exc_time)

        # perform vector search for the relevent column
        column_result, exc_time = opensearch_client.search_document(
            transaction_id=self.conversation.id,
            index_name="column index",
            query_body={},
        )
        self.opensearch.searchIndex.append("column index")
        self.opensearch.searchQuery.append({})
        self.opensearch.searchResult.append(column_result)
        self.opensearch.executionTime.append(exc_time)

        schema = "TODO : Create table and column schema"
        # create the prompt for the sql generation
        text2sql_prompt = text2sql_prompt_builder(
            transaction_id=self.conversation.id,
            query=self.conversation.query,
            schema=schema,
        )

        # bedrock call for the sql generation
        self.conversation.sqlResponse, exc_time = await bedrock_client.async_converse(
            transaction_id=self.conversation.id,
            model_id="cloude model",
            messages=text2sql_prompt,
            model_params={},
        )

        self.bedrock.callType.append("chat")
        self.bedrock.inputToken.append("to be checked")
        self.bedrock.outputToken.append("to be checked")
        self.bedrock.totalToken.append("to be calculated")
        self.bedrock.response.append(query_embedding_response)
        self.bedrock.executionTime.append(exc_time)

        # parsing the generated (sql glot, LLM as judge)
        self.conversation.sqlResponse = text2sql_response_parser(
            transaction_id=self.conversation.id,
            llm_response=self.conversation.sqlResponse,
        )

        # exectue the query over databricks(through the nodejs adapter)
        # TODO : need to implement this part once the understanding of nodejs middleware

        # generate text + graph for the query
        # TODO : if any kind of condition that need to implmented for graph generation
        # TODO : finalise the parameters for the graph generation
        graph_prompt = graph_prompt_builder(
            transaction_id=self.conversation.id, data=[], query=self.conversation.query
        )

        self.conversation.graphResponse, exc_time = await bedrock_client.async_converse(
            transaction_id=self.conversation.id,
            model_id="cloude model",
            messages=graph_prompt,
            model_params={},
        )

        self.bedrock.callType.append("chat")
        self.bedrock.inputToken.append("to be checked")
        self.bedrock.outputToken.append("to be checked")
        self.bedrock.totalToken.append("to be calculated")
        self.bedrock.response.append(query_embedding_response)
        self.bedrock.executionTime.append(exc_time)

        # generate text for the query
        # TODO : if any kind of condition that need to implmented for text generation
        # TODO : finalise the parameters for the text generation
        text_prompt = sum_prompt_builder(
            transaction_id=self.conversation.id, data=[], query=self.conversation.query
        )

        self.conversation.graphResponse, exc_time = await bedrock_client.async_converse(
            transaction_id=self.conversation.id,
            model_id="cloude model",
            messages=text_prompt,
            model_params={},
        )

        self.bedrock.callType.append("chat")
        self.bedrock.inputToken.append("to be checked")
        self.bedrock.outputToken.append("to be checked")
        self.bedrock.totalToken.append("to be calculated")
        self.bedrock.response.append(query_embedding_response)
        self.bedrock.executionTime.append(exc_time)
        # return the response
        # possible datamodels required : ConversationModel, bedrockanalyticsmodel,

        return self.conversation, self.bedrock, self.opensearch
