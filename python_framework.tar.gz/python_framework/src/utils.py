from src.logger import logger
from typing import Any, Dict, List
from sqlglot import parse_one, exp
from sqlglot.expressions import Literal, In, EQ, Between, Column


def text2sql_response_parser(transaction_id: str, llm_response: Any):
    """
    Method to parse the response for text 2 sql conversion using sql glot
    TODO : SQLglot based parser
    1. check column contains permitted table name and column names
    2. check it's a select statement only, not making any kind of change in the data
    """
    parsed_response = ""
    try:
        sql_query = llm_response["output"]["message"]["content"][0]["text"]
        expression = parse_one(sql_query)
        assert expression.key == "select"
        # TODO : implement the column check and table check logic
        # expression = parse_one(sql_query)

        # # Extract all column references
        # columns = {col.name for col in expression.find_all(exp.Column)}

        # # Extract all alias names
        # aliases = {alias.alias for alias in expression.find_all(exp.Alias)}

        # # Filter out alias names
        # actual_columns = columns - aliases


        # tables = []
        # for table in expression.find_all(exp.Table):
        #     tables.append(table.name)

        # set(tables)

    except Exception as ex:
        raise
    return parsed_response


def handle_eq_condition(
    node, transaction_id: str, threshold: float, table_name: str, string_columns
):
    node_left = node.left.this.sql()
    node_right = node.right.this

    if node_left in string_columns:
        node_right = str(node_right)
        node_right = node_right.strip("'")
        # emb_time, value_embedding = create_embedding(transaction_id, node_right)
        # new_value, score = search_redis_index(transaction_id, value_embedding, RedisConfig().INDEX_NAME_5, threshold=0.15, table_name=table_name, column_name=node_left)
        # if new_value:
        #     node.replace(f"{node_left} = '{new_value}'")
        # else:
        #     clean_up_parent(node)

    return True


def handle_in_condition(
    node,
    transaction_id: str,
    valid_ids: set,
    threshold: float,
    table_name: str,
    string_columns,
):
    final_values = []
    column_name = node.args["this"].this
    column_values = [
        str(literal.this).strip("'") for literal in node.args["expressions"]
    ]
    column = column_name.sql()

    # if column in string_columns:
    #     for value in column_values:
    #         emb_time, value_embedding = create_embedding(transaction_id, value)
    #         new_value, score = search_redis_index(transaction_id=transaction_id, vector_dimensions=value_embedding,index_name= RedisConfig().INDEX_NAME_5, threshold=0.15, table_name=table_name, column_name = column)
    #         if new_value:
    #             final_values.append(new_value)
    #         else:
    #             final_values.append(value)

    if final_values:
        node.set("expressions", [Literal.string(f"{v}") for v in final_values])
    # else:
    #     clean_up_parent(node)
    return True


def process_node(
    node, transaction_id, valid_ids, threshold, table_name, string_columns
):
    """
    Method to process the individual nodes
    TODO : complete the Between condition node
    """
    if isinstance(node, EQ):
        return handle_eq_condition(
            node, transaction_id, valid_ids, threshold, table_name, string_columns
        )
    elif isinstance(node, In):
        return handle_in_condition(
            node, transaction_id, valid_ids, threshold, table_name, string_columns
        )
    # elif isinstance(node, Between):
    #     return handle_between_condition(node)
    return True


def mapping_column_values(
    transaction_id: str, table_name: str, string_columns: str, threshold: float = 1.0
):
    """
    Method to replace most relevent matching value of a column in sql query using sql glot
    TODO : sql glot based implementation
    1. find the conditions which can have categorical columns
    2. impute the possible change related value for the condition(can be eq, in or b/w condition)
    3. Make it compatible to multiple table and column(right now only supports single table)
    """
    valid_query = True

    def replace_value(node):
        nonlocal valid_query
        if not process_node(
            node, transaction_id, threshold, table_name, string_columns
        ):
            valid_query = False
        return node

    ast = ast.transform(replace_value)
    if not valid_query:
        return "None"

    modified_sql = ast.sql()
    logger.info(
        f"[utils][replace_dimension_value][{transaction_id}] - Replaced categorical values using the respective Redis indexer"
    )
    return modified_sql


def text2sql_response_builder():
    """
    Method to create a response for the text2sql route.
    """
    pass


def databricks_executor():
    """
    Method to execute databrick query over nodejs middelware, which then executes the query over databricks to show the results
    """
    pass


def fetch_prompt():
    """
    Method to fetch the prompt from a storage
    TODO : Decide the storage and prompt schema. To be implemented
    """
    pass
