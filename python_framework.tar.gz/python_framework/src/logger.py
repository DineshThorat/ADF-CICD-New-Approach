import logging


def logger_setup():
    """
    Method to log messages to Azure Application Insights

    Returns:
        logger: Logger object
    """

    logging.basicConfig(
        filename="logs.log",
        format="{asctime} - {levelname} - {message}",
        style="{",
        datefmt="%Y-%m-%d %H:%M",
        level=logging.INFO,
    )
    logger = logging.getLogger(__name__)
    logger.info("Logger Initialised..")
    return logger


logger = logger_setup()
